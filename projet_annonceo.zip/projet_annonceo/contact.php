<?php

require_once('inc/init.php');
require_once('inc/header.php');

