</div>

<footer>

</footer>

<script src="<?= RACINE_SITE.'inc/js/jquery-3.3.1.min.js' ?>"></script>
<script src="<?= RACINE_SITE.'inc/js/bootstrap.min.js' ?>"></script>
<script src="<?= RACINE_SITE.'inc/js/nouislider.min.js' ?>"></script>
</body>

</html>